'use strict';

module.exports = {
  'home': require('./home'),
  'signup': require('./signup'),
  'login': require('./login'),
  'profile': require('./profile'),
  'user': require('./user')
};
